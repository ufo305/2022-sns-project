# 동대멋사 여름학기 세션

1. 실행 방법  
```
cd backend
python3 manage.py runserver
```

2. 리액트 프로젝트 생성
```
create-react-app frontend
cd frontend
npm run start
```
